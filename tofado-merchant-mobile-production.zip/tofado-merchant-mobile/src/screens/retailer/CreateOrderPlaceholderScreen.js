import { Pressable, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";

import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";

export default function CreateOrderPlaceholderScreen({ route, navigation }) {
  const { wholesalerName } = route.params || {};

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={styles.page}>
        <MobileHeader
          eyebrow="Next stage"
          title="Create purchase order"
          subtitle={
            wholesalerName
              ? `Selected wholesaler: ${wholesalerName}`
              : "Create a purchase list for a connected wholesaler."
          }
          onBack={() => navigation.goBack()}
        />

        <View style={styles.card}>
          <View style={styles.icon}>
            <Ionicons
              name="bag-add-outline"
              size={28}
              color={colors.primary}
            />
          </View>

          <Text style={styles.title}>Vendor selection is working</Text>
          <Text style={styles.copy}>
            Stage 3 will add the complete mobile purchase-list builder,
            multiple products, units, delivery address, required date,
            notes, submission, and order tracking.
          </Text>

          <Pressable style={styles.button} onPress={() =>
              navigation.getParent()?.navigate("RetailerOrders", {
                screen: "CreateOrder",
                params: {
                  wholesalerId: route.params?.wholesalerId,
                  wholesalerName,
                },
              })
            }>
            <Text style={styles.buttonText}>Continue to purchase order</Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { flex: 1, padding: 20 },
  card: {
    flex: 1,
    minHeight: 320,
    alignItems: "center",
    justifyContent: "center",
    padding: 28,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 20,
    backgroundColor: colors.white,
  },
  icon: {
    width: 62,
    height: 62,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    backgroundColor: colors.primarySoft,
  },
  title: {
    marginTop: 16,
    color: colors.ink,
    fontSize: 17,
    fontWeight: "900",
    textAlign: "center",
  },
  copy: {
    marginTop: 8,
    color: colors.body,
    fontSize: 11,
    lineHeight: 18,
    textAlign: "center",
  },
  button: {
    minHeight: 43,
    marginTop: 17,
    justifyContent: "center",
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: colors.primary,
  },
  buttonText: {
    color: colors.white,
    fontSize: 10,
    fontWeight: "900",
  },
});
