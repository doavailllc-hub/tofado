import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";

import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import VendorCard from "../../components/VendorCard";

function actionFor(vendor) {
  const status = String(vendor.connection_status || "").toLowerCase();

  if (status === "active") {
    return {
      label: "Connected",
      icon: "checkmark-circle-outline",
      disabled: true,
    };
  }

  if (status === "pending") {
    return {
      label: "Request pending",
      icon: "time-outline",
      disabled: true,
    };
  }

  if (status === "blocked") {
    return {
      label: "Unavailable",
      icon: "close-circle-outline",
      disabled: true,
    };
  }

  return {
    label: status === "rejected" ? "Request again" : "Send request",
    icon: "paper-plane-outline",
    disabled: false,
  };
}

export default function FindWholesalersScreen({ navigation }) {
  const [query, setQuery] = useState("");
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sendingId, setSendingId] = useState(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const search = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const { data } = await api.get("/retailer/wholesalers/search", {
        params: { q: query.trim() },
      });

      setVendors(
        Array.isArray(data)
          ? data
          : Array.isArray(data?.wholesalers)
            ? data.wholesalers
            : []
      );
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          "Unable to search wholesalers."
      );
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => {
    const timer = setTimeout(search, 300);
    return () => clearTimeout(timer);
  }, [search]);

  const sendRequest = async (vendor) => {
    try {
      setSendingId(vendor.id);
      setError("");
      setNotice("");

      const { data } = await api.post(
        `/retailer/wholesalers/${vendor.id}/request`,
        {}
      );

      setVendors((current) =>
        current.map((item) =>
          item.id === vendor.id
            ? {
                ...item,
                connection_status: "pending",
                connection_id: data?.connection_id || item.connection_id,
              }
            : item
        )
      );

      setNotice(data?.message || "Connection request sent.");
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          "Unable to send connection request."
      );
    } finally {
      setSendingId(null);
    }
  };

  const summary = useMemo(() => {
    return vendors.reduce(
      (acc, item) => {
        acc.total += 1;
        if (item.connection_status === "active") acc.connected += 1;
        if (item.connection_status === "pending") acc.pending += 1;
        return acc;
      },
      { total: 0, connected: 0, pending: 0 }
    );
  }, [vendors]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page}>
        <MobileHeader
          eyebrow="Vendor discovery"
          title="Find wholesalers"
          subtitle="Search verified suppliers and request permission to order."
          onBack={() => navigation.goBack()}
        />

        <View style={styles.search}>
          <Ionicons name="search-outline" size={19} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Business, category or location"
            placeholderTextColor={colors.muted}
            style={styles.input}
          />
          {!!query && (
            <Pressable onPress={() => setQuery("")}>
              <Ionicons name="close-circle" size={19} color={colors.muted} />
            </Pressable>
          )}
        </View>

        <View style={styles.summary}>
          <View>
            <Text style={styles.summaryValue}>{summary.total}</Text>
            <Text style={styles.summaryLabel}>Found</Text>
          </View>
          <View>
            <Text style={styles.summaryValue}>{summary.connected}</Text>
            <Text style={styles.summaryLabel}>Connected</Text>
          </View>
          <View>
            <Text style={styles.summaryValue}>{summary.pending}</Text>
            <Text style={styles.summaryLabel}>Pending</Text>
          </View>
        </View>

        {!!error && (
          <View style={styles.error}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}

        {!!notice && (
          <View style={styles.notice}>
            <Text style={styles.noticeText}>{notice}</Text>
          </View>
        )}

        {loading ? (
          <View style={styles.loading}>
            <ActivityIndicator color={colors.primary} />
            <Text style={styles.loadingText}>Searching wholesalers…</Text>
          </View>
        ) : vendors.length ? (
          <View style={styles.list}>
            {vendors.map((vendor) => {
              const action = actionFor(vendor);
              const isSending = sendingId === vendor.id;

              return (
                <VendorCard
                  key={vendor.id}
                  vendor={vendor}
                  actionLabel={isSending ? "Sending…" : action.label}
                  actionIcon={action.icon}
                  disabled={action.disabled || isSending}
                  onPress={() => sendRequest(vendor)}
                />
              );
            })}
          </View>
        ) : (
          <View style={styles.empty}>
            <Ionicons name="search-outline" size={30} color={colors.muted} />
            <Text style={styles.emptyTitle}>No wholesalers found</Text>
            <Text style={styles.emptyCopy}>
              Try another business name, category, or location.
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  search: {
    minHeight: 50,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    backgroundColor: colors.soft,
  },
  input: {
    flex: 1,
    minHeight: 48,
    color: colors.ink,
    fontSize: 12,
  },
  summary: {
    marginTop: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 15,
    borderRadius: 15,
    backgroundColor: colors.primarySoft,
  },
  summaryValue: {
    color: colors.ink,
    fontSize: 18,
    fontWeight: "900",
    textAlign: "center",
  },
  summaryLabel: {
    marginTop: 3,
    color: colors.body,
    fontSize: 8,
    fontWeight: "700",
    textAlign: "center",
  },
  error: {
    marginTop: 12,
    padding: 11,
    borderRadius: 11,
    backgroundColor: colors.redSoft,
  },
  errorText: { color: colors.red, fontSize: 10 },
  notice: {
    marginTop: 12,
    padding: 11,
    borderRadius: 11,
    backgroundColor: colors.greenSoft,
  },
  noticeText: { color: "#15803D", fontSize: 10 },
  loading: {
    minHeight: 280,
    alignItems: "center",
    justifyContent: "center",
  },
  loadingText: {
    marginTop: 9,
    color: colors.body,
    fontSize: 10,
  },
  list: { marginTop: 14, gap: 11 },
  empty: {
    minHeight: 280,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyTitle: {
    marginTop: 10,
    color: colors.ink,
    fontSize: 14,
    fontWeight: "900",
  },
  emptyCopy: {
    marginTop: 5,
    color: colors.body,
    fontSize: 10,
  },
});
