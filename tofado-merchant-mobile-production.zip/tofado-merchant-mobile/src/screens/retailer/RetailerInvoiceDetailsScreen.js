import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import StatusBadge from "../../components/StatusBadge";
import { date, money, title } from "../../utils/format";

export default function RetailerInvoiceDetailsScreen({ route, navigation }) {
  const { id } = route.params;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("bank_transfer");
  const [reference, setReference] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = useCallback(async (refresh = false) => {
    try {
      refresh ? setRefreshing(true) : setLoading(true);
      setError("");
      const { data } = await api.get(`/retailer/invoices/${id}`);
      setData(data);
      if (!amount && Number(data?.invoice?.outstanding_amount || 0) > 0) {
        setAmount(Number(data.invoice.outstanding_amount).toFixed(2));
      }
    } catch (e) {
      setError(e?.response?.data?.message || "Unable to load invoice.");
    } finally {
      setLoading(false); setRefreshing(false);
    }
  }, [id, amount]);

  useEffect(() => { load(); }, [load]);

  const submit = async () => {
    try {
      setSaving(true); setError(""); setNotice("");
      const { data: result } = await api.post(`/retailer/invoices/${id}/payments`, {
        amount: Number(amount),
        method,
        reference_no: reference.trim() || null,
      });
      setNotice(result?.message || "Payment submitted.");
      setReference("");
      await load(true);
    } catch (e) {
      setError(e?.response?.data?.message || "Unable to submit payment.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <SafeAreaView style={styles.safe}><View style={styles.loading}><ActivityIndicator color={colors.primary} /></View></SafeAreaView>;

  const invoice = data?.invoice || {};
  const items = data?.items || [];
  const payments = data?.payments || [];
  const outstanding = Number(invoice.outstanding_amount || 0);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} />}>
        <MobileHeader eyebrow="Invoice" title={invoice.invoice_no || `Invoice #${id}`} subtitle={invoice.wholesaler_name || "Wholesaler"} onBack={() => navigation.goBack()} />
        {!!error && <Text style={styles.error}>{error}</Text>}
        {!!notice && <Text style={styles.notice}>{notice}</Text>}

        <View style={styles.hero}>
          <View><Text style={styles.kicker}>TOTAL</Text><Text style={styles.total}>{money(invoice.total_amount)}</Text></View>
          <StatusBadge status={invoice.calculated_payment_status || invoice.payment_status || invoice.status} />
        </View>

        <View style={styles.card}>
          <Row label="Order" value={invoice.order_no} />
          <Row label="Due date" value={date(invoice.payment_due_date)} />
          <Row label="Payment type" value={title(invoice.payment_type)} />
          <Row label="Paid" value={money(invoice.paid_amount)} />
          <Row label="Outstanding" value={money(invoice.outstanding_amount)} />
        </View>

        <Text style={styles.section}>Items</Text>
        <View style={styles.card}>
          {items.map((item, i) => <View style={styles.item} key={item.id || i}><View style={styles.itemCopy}><Text style={styles.itemName}>{item.product_name}</Text><Text style={styles.itemMeta}>{item.quantity} {item.unit || ""}</Text></View><Text style={styles.itemPrice}>{money(item.line_total)}</Text></View>)}
        </View>

        <Text style={styles.section}>Payment history</Text>
        <View style={styles.card}>
          {payments.length ? payments.map((p) => <View style={styles.payment} key={p.id}><View style={styles.itemCopy}><Text style={styles.itemName}>{p.payment_no}</Text><Text style={styles.itemMeta}>{title(p.method)} · {date(p.paid_at || p.created_at)}</Text></View><View style={styles.paymentRight}><Text style={styles.itemPrice}>{money(p.amount)}</Text><StatusBadge status={p.status} /></View></View>) : <Text style={styles.empty}>No payments recorded.</Text>}
        </View>

        {outstanding > 0 && invoice.status !== "cancelled" && <>
          <Text style={styles.section}>Submit payment</Text>
          <View style={styles.form}>
            <TextInput value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="Amount" placeholderTextColor={colors.muted} style={styles.input} />
            <View style={styles.methods}>
              {["bank_transfer", "card", "cash", "credit"].map((m) => <Pressable key={m} onPress={() => setMethod(m)} style={[styles.method, method === m && styles.methodActive]}><Text style={[styles.methodText, method === m && styles.methodTextActive]}>{title(m)}</Text></Pressable>)}
            </View>
            <TextInput value={reference} onChangeText={setReference} placeholder="Payment reference" placeholderTextColor={colors.muted} style={styles.input} />
            <Pressable disabled={saving} onPress={submit} style={[styles.submit, saving && styles.disabled]}>{saving ? <ActivityIndicator color={colors.white} /> : <Text style={styles.submitText}>Submit for verification</Text>}</Pressable>
          </View>
        </>}
      </ScrollView>
    </SafeAreaView>
  );
}

function Row({ label, value }) { return <View style={styles.row}><Text style={styles.rowLabel}>{label}</Text><Text style={styles.rowValue}>{value || "—"}</Text></View>; }

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 40 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 10, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
  notice: { marginBottom: 10, padding: 11, borderRadius: 11, color: "#15803D", backgroundColor: colors.greenSoft, fontSize: 10 },
  hero: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 16, borderRadius: 16, backgroundColor: colors.primarySoft },
  kicker: { color: colors.body, fontSize: 8, fontWeight: "900" },
  total: { marginTop: 5, color: colors.ink, fontSize: 20, fontWeight: "900" },
  section: { marginTop: 20, marginBottom: 9, color: colors.ink, fontSize: 15, fontWeight: "900" },
  card: { overflow: "hidden", borderWidth: 1, borderColor: colors.border, borderRadius: 16 },
  row: { padding: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
  rowLabel: { color: colors.muted, fontSize: 8 },
  rowValue: { marginTop: 4, color: colors.ink, fontSize: 10, fontWeight: "800" },
  item: { minHeight: 58, padding: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  itemCopy: { flex: 1 },
  itemName: { color: colors.ink, fontSize: 10, fontWeight: "800" },
  itemMeta: { marginTop: 4, color: colors.body, fontSize: 9 },
  itemPrice: { color: colors.ink, fontSize: 9, fontWeight: "900" },
  payment: { minHeight: 70, padding: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  paymentRight: { alignItems: "flex-end", gap: 5 },
  empty: { padding: 20, color: colors.body, fontSize: 10, textAlign: "center" },
  form: { gap: 10, padding: 14, borderWidth: 1, borderColor: colors.border, borderRadius: 16 },
  input: { minHeight: 45, paddingHorizontal: 11, borderWidth: 1, borderColor: colors.border, borderRadius: 11, color: colors.ink, backgroundColor: colors.soft, fontSize: 11 },
  methods: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  method: { minHeight: 36, justifyContent: "center", paddingHorizontal: 10, borderWidth: 1, borderColor: colors.border, borderRadius: 999 },
  methodActive: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  methodText: { color: colors.body, fontSize: 8, fontWeight: "800" },
  methodTextActive: { color: colors.primary },
  submit: { minHeight: 46, alignItems: "center", justifyContent: "center", borderRadius: 12, backgroundColor: colors.primary },
  disabled: { opacity: 0.6 },
  submitText: { color: colors.white, fontSize: 10, fontWeight: "900" },
});
