import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import StatusBadge from "../../components/StatusBadge";
import { date, money, title } from "../../utils/format";

export default function RetailerOrderDetailsScreen({ route, navigation }) {
  const { id } = route.params;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async (refresh = false) => {
    try {
      refresh ? setRefreshing(true) : setLoading(true);
      setError("");
      const { data } = await api.get(`/retailer/orders/${id}`);
      setData(data);
    } catch (e) {
      setError(e?.response?.data?.message || "Unable to load order.");
    } finally {
      setLoading(false); setRefreshing(false);
    }
  }, [id]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <SafeAreaView style={styles.safe}><View style={styles.loading}><ActivityIndicator color={colors.primary} /></View></SafeAreaView>;

  const order = data?.order || {};
  const items = data?.items || [];
  const invoice = data?.invoice;
  const delivery = data?.delivery;

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} />}>
        <MobileHeader eyebrow="Purchase order" title={order.order_no || `Order #${id}`} subtitle={order.wholesaler_name || "Wholesaler"} onBack={() => navigation.goBack()} />
        {!!error && <Text style={styles.error}>{error}</Text>}
        <View style={styles.hero}>
          <View><Text style={styles.kicker}>TOTAL</Text><Text style={styles.total}>{money(order.total_amount)}</Text></View>
          <StatusBadge status={order.status} />
        </View>

        <Text style={styles.section}>Order information</Text>
        <View style={styles.card}>
          <Row label="Created" value={date(order.created_at)} />
          <Row label="Required date" value={date(order.required_date)} />
          <Row label="Delivery address" value={order.delivery_address} />
          <Row label="Notes" value={order.notes || "—"} />
        </View>

        <Text style={styles.section}>Products</Text>
        <View style={styles.card}>
          {items.map((item, index) => (
            <View style={styles.item} key={item.id || index}>
              <View style={styles.itemCopy}><Text style={styles.itemName}>{item.product_name}</Text><Text style={styles.itemMeta}>{item.quantity} {item.unit || ""}</Text></View>
              <Text style={styles.itemPrice}>{item.unit_price == null ? "Awaiting price" : money(item.line_total)}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.section}>Invoice & delivery</Text>
        <View style={styles.card}>
          <Row label="Invoice" value={invoice ? `${invoice.invoice_no || `#${invoice.id}`} · ${title(invoice.payment_status || invoice.status)}` : "Not issued"} />
          <Row label="Delivery" value={delivery ? `${title(delivery.status)} · ${delivery.delivery_no || `#${delivery.id}`}` : "Not created"} />
          {!!delivery?.driver_name && <Row label="Driver" value={delivery.driver_name} />}
          {!!delivery?.vehicle_number && <Row label="Vehicle" value={delivery.vehicle_number} />}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Row({ label, value }) {
  return <View style={styles.row}><Text style={styles.rowLabel}>{label}</Text><Text style={styles.rowValue}>{value || "—"}</Text></View>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 12, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
  hero: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 16, borderRadius: 16, backgroundColor: colors.primarySoft },
  kicker: { color: colors.body, fontSize: 8, fontWeight: "900" },
  total: { marginTop: 5, color: colors.ink, fontSize: 20, fontWeight: "900" },
  section: { marginTop: 20, marginBottom: 9, color: colors.ink, fontSize: 15, fontWeight: "900" },
  card: { overflow: "hidden", borderWidth: 1, borderColor: colors.border, borderRadius: 16 },
  row: { padding: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
  rowLabel: { color: colors.muted, fontSize: 8 },
  rowValue: { marginTop: 4, color: colors.ink, fontSize: 10, fontWeight: "800" },
  item: { minHeight: 58, padding: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  itemCopy: { flex: 1 },
  itemName: { color: colors.ink, fontSize: 10, fontWeight: "800" },
  itemMeta: { marginTop: 4, color: colors.body, fontSize: 9 },
  itemPrice: { color: colors.ink, fontSize: 9, fontWeight: "900" },
});
