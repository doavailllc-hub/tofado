import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";

const newItem = () => ({ key: `${Date.now()}-${Math.random()}`, product_name: "", quantity: "1", unit: "piece", notes: "" });

export default function CreateOrderScreen({ navigation, route }) {
  const [vendors, setVendors] = useState([]);
  const [wholesalerId, setWholesalerId] = useState(route.params?.wholesalerId || null);
  const [address, setAddress] = useState("");
  const [requiredDate, setRequiredDate] = useState("");
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState([newItem()]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      const { data } = await api.get("/retailer/wholesalers");
      const list = Array.isArray(data) ? data : data?.wholesalers || [];
      setVendors(list);
      setWholesalerId((current) => current || list[0]?.id || null);
    } catch (e) {
      setError(e?.response?.data?.message || "Unable to load connected wholesalers.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateItem = (key, field, value) =>
    setItems((current) => current.map((x) => x.key === key ? { ...x, [field]: value } : x));

  const submit = async () => {
    try {
      setSaving(true);
      setError("");
      const clean = items.map((x) => ({
        product_name: x.product_name.trim(),
        quantity: Number(x.quantity),
        unit: x.unit.trim() || "piece",
        notes: x.notes.trim() || null,
      })).filter((x) => x.product_name && x.quantity > 0);

      if (!wholesalerId || !address.trim() || !clean.length) {
        setError("Wholesaler, delivery address, and at least one product are required.");
        return;
      }

      const { data } = await api.post("/retailer/orders", {
        wholesaler_id: wholesalerId,
        delivery_address: address.trim(),
        required_date: requiredDate.trim() || null,
        notes: notes.trim() || null,
        items: clean,
      });

      navigation.replace("RetailerOrderDetails", { id: data.id });
    } catch (e) {
      setError(e?.response?.data?.message || "Unable to create order.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <SafeAreaView style={styles.safe}><View style={styles.loading}><ActivityIndicator color={colors.primary} /></View></SafeAreaView>;

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
        <MobileHeader eyebrow="Purchase order" title="New purchase list" subtitle="Order from an accepted wholesaler." onBack={() => navigation.goBack()} />
        {!!error && <Text style={styles.error}>{error}</Text>}

        <Text style={styles.label}>Wholesaler</Text>
        <View style={styles.vendorList}>
          {vendors.map((v) => (
            <Pressable key={v.id} onPress={() => setWholesalerId(v.id)} style={[styles.vendor, Number(wholesalerId) === Number(v.id) && styles.vendorSelected]}>
              <Ionicons name="business-outline" size={18} color={colors.primary} />
              <Text style={styles.vendorText}>{v.business_name}</Text>
              {Number(wholesalerId) === Number(v.id) && <Ionicons name="checkmark-circle" size={18} color={colors.primary} />}
            </Pressable>
          ))}
        </View>

        <Text style={styles.label}>Delivery address</Text>
        <TextInput value={address} onChangeText={setAddress} multiline placeholder="Delivery address" placeholderTextColor={colors.muted} style={[styles.input, styles.textarea]} />

        <Text style={styles.label}>Required date</Text>
        <TextInput value={requiredDate} onChangeText={setRequiredDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.muted} style={styles.input} />

        <View style={styles.sectionRow}>
          <Text style={styles.sectionTitle}>Products</Text>
          <Pressable style={styles.add} onPress={() => setItems((current) => [...current, newItem()])}>
            <Ionicons name="add" size={16} color={colors.primary} />
            <Text style={styles.addText}>Add item</Text>
          </Pressable>
        </View>

        <View style={styles.items}>
          {items.map((item, index) => (
            <View style={styles.item} key={item.key}>
              <View style={styles.itemHead}>
                <Text style={styles.itemNo}>Item {index + 1}</Text>
                {items.length > 1 && <Pressable onPress={() => setItems((current) => current.filter((x) => x.key !== item.key))}><Ionicons name="trash-outline" size={17} color={colors.red} /></Pressable>}
              </View>
              <TextInput value={item.product_name} onChangeText={(v) => updateItem(item.key, "product_name", v)} placeholder="Product name" placeholderTextColor={colors.muted} style={styles.input} />
              <View style={styles.two}>
                <TextInput value={item.quantity} onChangeText={(v) => updateItem(item.key, "quantity", v)} keyboardType="decimal-pad" placeholder="Qty" placeholderTextColor={colors.muted} style={[styles.input, styles.half]} />
                <TextInput value={item.unit} onChangeText={(v) => updateItem(item.key, "unit", v)} placeholder="Unit" placeholderTextColor={colors.muted} style={[styles.input, styles.half]} />
              </View>
              <TextInput value={item.notes} onChangeText={(v) => updateItem(item.key, "notes", v)} placeholder="Item notes" placeholderTextColor={colors.muted} style={styles.input} />
            </View>
          ))}
        </View>

        <Text style={styles.label}>Order notes</Text>
        <TextInput value={notes} onChangeText={setNotes} multiline placeholder="Optional note" placeholderTextColor={colors.muted} style={[styles.input, styles.textarea]} />

        <Pressable disabled={saving || !vendors.length} style={[styles.submit, (saving || !vendors.length) && styles.disabled]} onPress={submit}>
          {saving ? <ActivityIndicator color={colors.white} /> : <Text style={styles.submitText}>Send purchase order</Text>}
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 40 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 12, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
  label: { marginTop: 15, marginBottom: 7, color: colors.ink, fontSize: 10, fontWeight: "800" },
  vendorList: { gap: 8 },
  vendor: { minHeight: 48, flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.border, borderRadius: 12 },
  vendorSelected: { borderColor: "#93C5FD", backgroundColor: colors.primarySoft },
  vendorText: { flex: 1, color: colors.ink, fontSize: 10, fontWeight: "800" },
  input: { minHeight: 46, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.border, borderRadius: 12, color: colors.ink, backgroundColor: colors.soft, fontSize: 11 },
  textarea: { minHeight: 82, paddingTop: 12, textAlignVertical: "top" },
  sectionRow: { marginTop: 21, marginBottom: 10, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sectionTitle: { color: colors.ink, fontSize: 15, fontWeight: "900" },
  add: { flexDirection: "row", alignItems: "center", gap: 4 },
  addText: { color: colors.primary, fontSize: 10, fontWeight: "900" },
  items: { gap: 10 },
  item: { padding: 13, gap: 9, borderWidth: 1, borderColor: colors.border, borderRadius: 15 },
  itemHead: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  itemNo: { color: colors.primary, fontSize: 9, fontWeight: "900" },
  two: { flexDirection: "row", gap: 8 },
  half: { flex: 1 },
  submit: { minHeight: 50, marginTop: 22, alignItems: "center", justifyContent: "center", borderRadius: 13, backgroundColor: colors.primary },
  disabled: { opacity: 0.55 },
  submitText: { color: colors.white, fontSize: 11, fontWeight: "900" },
});
