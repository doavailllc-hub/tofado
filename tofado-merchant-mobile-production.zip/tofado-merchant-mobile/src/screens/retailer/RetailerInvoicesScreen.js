import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import RecordCard from "../../components/RecordCard";
import EmptyState from "../../components/EmptyState";
import { money, date } from "../../utils/format";

export default function RetailerInvoicesScreen({ navigation }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async (refresh = false) => {
    try {
      refresh ? setRefreshing(true) : setLoading(true);
      setError("");
      const { data } = await api.get("/retailer/invoices");
      setRows(Array.isArray(data) ? data : data?.rows || data?.orders || data?.invoices || data?.payments || data?.deliveries || data?.products || data?.retailers || []);
    } catch (e) {
      setError(e?.response?.data?.message || "Unable to load data.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView
        contentContainerStyle={styles.page}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} tintColor={colors.primary} />}
      >
        <MobileHeader eyebrow="Finance" title="Invoices" subtitle="Review balances, due dates, and payment status." />
        {!!error && <Text style={styles.error}>{error}</Text>}

        {loading ? (
          <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View>
        ) : rows.length ? (
          <View style={styles.list}>
            {rows.map((row) => (
              <RecordCard
                key={row.id}
                icon="receipt-outline"
                title={row.invoice_no || `Invoice #${row.id}`}
                subtitle={`${row.wholesaler_name || "Wholesaler"} · ${row.order_no || ""}`}
                meta={`Due ${date(row.payment_due_date || row.due_date)}`}
                amount={money(row.total_amount)}
                status={row.payment_status || row.status}
                onPress={() => navigation.navigate("RetailerInvoiceDetails", { id: row.id })}
              />
            ))}
          </View>
        ) : (
          <EmptyState icon="receipt-outline" title="Nothing here yet" copy="Records will appear here when available." />
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  list: { gap: 0 },
  loading: { minHeight: 300, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 12, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
});
