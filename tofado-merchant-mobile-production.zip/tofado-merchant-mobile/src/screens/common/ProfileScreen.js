import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";

import { useAuth } from "../../context/AuthContext";
import { colors } from "../../theme/colors";

function Row({ icon, label, value }) {
  return (
    <View style={styles.row}>
      <View style={styles.rowIcon}>
        <Ionicons name={icon} size={18} color={colors.primary} />
      </View>
      <View style={styles.rowCopy}>
        <Text style={styles.rowLabel}>{label}</Text>
        <Text style={styles.rowValue}>{value || "—"}</Text>
      </View>
    </View>
  );
}

export default function ProfileScreen() {
  const { user, logout } = useAuth();

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page}>
        <Text style={styles.eyebrow}>BUSINESS PROFILE</Text>
        <Text style={styles.title}>Your account</Text>
        <Text style={styles.subtitle}>
          Account information synced with Tofado Merchant.
        </Text>

        <View style={styles.identity}>
          <View style={styles.avatar}>
            {user?.logo_url ? (
              <Image source={{ uri: user.logo_url }} style={styles.logo} />
            ) : (
              <Ionicons
                name="business-outline"
                color={colors.primary}
                size={26}
              />
            )}
          </View>
          <View style={styles.identityCopy}>
            <Text style={styles.business}>
              {user?.business_name || user?.name || "Tofado Merchant"}
            </Text>
            <Text style={styles.role}>{user?.role || "merchant"}</Text>
          </View>
        </View>

        <View style={styles.card}>
          <Row icon="person-outline" label="Contact" value={user?.name} />
          <Row icon="mail-outline" label="Email" value={user?.email} />
          <Row
            icon="location-outline"
            label="Location"
            value={user?.location}
          />
          <Row
            icon="grid-outline"
            label="Category"
            value={user?.business_category || user?.shop_type}
          />
        </View>

        <Pressable style={styles.logout} onPress={logout}>
          <Ionicons name="log-out-outline" size={19} color={colors.red} />
          <Text style={styles.logoutText}>Sign out</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 40 },
  eyebrow: {
    color: colors.primary,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 0.8,
  },
  title: {
    marginTop: 7,
    color: colors.ink,
    fontSize: 30,
    fontWeight: "900",
    letterSpacing: -1,
  },
  subtitle: {
    marginTop: 7,
    color: colors.body,
    fontSize: 12,
  },
  identity: {
    marginTop: 24,
    flexDirection: "row",
    alignItems: "center",
    gap: 13,
    padding: 16,
    borderRadius: 18,
    backgroundColor: colors.primarySoft,
  },
  avatar: {
    width: 54,
    height: 54,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 16,
    backgroundColor: colors.white,
  },
  logo: { width: "100%", height: "100%", resizeMode: "contain" },
  identityCopy: { flex: 1 },
  business: { color: colors.ink, fontSize: 16, fontWeight: "900" },
  role: {
    marginTop: 4,
    color: colors.primary,
    fontSize: 10,
    fontWeight: "800",
    textTransform: "capitalize",
  },
  card: {
    marginTop: 16,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 18,
    overflow: "hidden",
  },
  row: {
    minHeight: 66,
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    paddingHorizontal: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  rowIcon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 11,
    backgroundColor: colors.primarySoft,
  },
  rowCopy: { flex: 1 },
  rowLabel: { color: colors.muted, fontSize: 9, fontWeight: "700" },
  rowValue: {
    marginTop: 4,
    color: colors.ink,
    fontSize: 12,
    fontWeight: "700",
  },
  logout: {
    minHeight: 48,
    marginTop: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderWidth: 1,
    borderColor: "#FECACA",
    borderRadius: 13,
    backgroundColor: colors.redSoft,
  },
  logoutText: { color: colors.red, fontSize: 12, fontWeight: "800" },
});
