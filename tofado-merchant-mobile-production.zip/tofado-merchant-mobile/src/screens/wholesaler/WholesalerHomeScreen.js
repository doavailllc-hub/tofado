import DashboardScreen from "../common/DashboardScreen";
export default function WholesalerHomeScreen(){return <DashboardScreen role="wholesaler"/>;}
