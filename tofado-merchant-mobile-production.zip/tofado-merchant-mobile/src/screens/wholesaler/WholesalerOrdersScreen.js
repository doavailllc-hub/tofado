import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import RecordCard from "../../components/RecordCard";
import EmptyState from "../../components/EmptyState";
import { date, money } from "../../utils/format";

export default function WholesalerOrdersScreen({ navigation }) {
  const [rows, setRows] = useState([]); const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false); const [error, setError] = useState("");

  const load = useCallback(async (refresh = false) => {
    try {
      refresh ? setRefreshing(true) : setLoading(true); setError("");
      const { data } = await api.get("/wholesaler/orders");
      setRows(Array.isArray(data) ? data : data?.orders || []);
    } catch (e) { setError(e?.response?.data?.message || "Unable to load orders."); }
    finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} />}>
        <MobileHeader eyebrow="Order desk" title="Retailer orders" subtitle="Manage incoming purchase orders and fulfilment." />
        {!!error && <Text style={styles.error}>{error}</Text>}
        {loading ? <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View> :
          rows.length ? <View style={styles.list}>{rows.map((row) => <RecordCard key={row.id} title={row.order_no || `Order #${row.id}`} subtitle={row.retailer_name} meta={`Required ${date(row.required_date)}`} amount={money(row.total_amount)} status={row.status} onPress={() => navigation.navigate("WholesalerOrderDetails", { id: row.id })} />)}</View> :
          <EmptyState icon="bag-handle-outline" title="No retailer orders" copy="New purchase orders will appear here." />}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  list: { gap: 0 },
  loading: { minHeight: 300, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 12, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
});
