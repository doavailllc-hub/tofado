import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import RecordCard from "../../components/RecordCard";
import EmptyState from "../../components/EmptyState";

export default function WholesalerRetailersScreen({ navigation }) {
  const [rows, setRows] = useState([]); const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true); const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async (refresh = false) => {
    try {
      refresh ? setRefreshing(true) : setLoading(true);
      const [a, b] = await Promise.allSettled([api.get("/wholesaler/retailers"), api.get("/wholesaler/retailer-requests")]);
      if (a.status === "fulfilled") setRows(Array.isArray(a.value.data) ? a.value.data : a.value.data?.retailers || []);
      if (b.status === "fulfilled") setRequests(Array.isArray(b.value.data) ? b.value.data : b.value.data?.requests || []);
    } finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} />}>
        <MobileHeader eyebrow="Retailer network" title="Retailers" subtitle="Connected retailer businesses and incoming requests." actionIcon="person-add-outline" onAction={() => navigation.navigate("RetailerRequests")} />
        <Pressable style={styles.requests} onPress={() => navigation.navigate("RetailerRequests")}>
          <View style={styles.icon}><Ionicons name="notifications-outline" size={19} color={colors.orange} /></View>
          <View style={styles.copy}><Text style={styles.reqTitle}>Retailer requests</Text><Text style={styles.reqText}>{requests.length} pending request{requests.length === 1 ? "" : "s"}</Text></View>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>
        {loading ? <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View> :
          rows.length ? <View style={styles.list}>{rows.map((row) => <RecordCard key={row.id || row.retailer_id} icon="storefront-outline" title={row.business_name || row.retailer_name} subtitle={row.location || row.contact_name || "Connected retailer"} meta={row.phone || row.email || ""} status="active" />)}</View> :
          <EmptyState icon="people-outline" title="No connected retailers" copy="Accepted retailer connections will appear here." />}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  requests: { marginBottom: 15, minHeight: 72, flexDirection: "row", alignItems: "center", gap: 10, padding: 13, borderRadius: 16, backgroundColor: colors.orangeSoft },
  icon: { width: 42, height: 42, alignItems: "center", justifyContent: "center", borderRadius: 12, backgroundColor: colors.white },
  copy: { flex: 1 },
  reqTitle: { color: colors.ink, fontSize: 11, fontWeight: "900" },
  reqText: { marginTop: 4, color: colors.body, fontSize: 9 },
  list: { gap: 0 },
  loading: { minHeight: 300, alignItems: "center", justifyContent: "center" },
});
