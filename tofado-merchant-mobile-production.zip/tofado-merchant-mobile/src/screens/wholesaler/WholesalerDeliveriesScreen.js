import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import RecordCard from "../../components/RecordCard";
import EmptyState from "../../components/EmptyState";
import { date } from "../../utils/format";

export default function WholesalerDeliveriesScreen() {
  const [rows, setRows] = useState([]); const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false); const [workingId, setWorkingId] = useState(null);
  const [error, setError] = useState("");

  const load = useCallback(async (refresh = false) => {
    try {
      refresh ? setRefreshing(true) : setLoading(true); setError("");
      const { data } = await api.get("/wholesaler/deliveries");
      setRows(Array.isArray(data) ? data : data?.deliveries || []);
    } catch (e) { setError(e?.response?.data?.message || "Unable to load deliveries."); }
    finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const update = async (row, status) => {
    try {
      setWorkingId(row.id);
      await api.patch(`/wholesaler/deliveries/${row.id}`, { status });
      setRows((current) => current.map((x) => x.id === row.id ? { ...x, status } : x));
    } catch (e) { setError(e?.response?.data?.message || "Unable to update delivery."); }
    finally { setWorkingId(null); }
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} />}>
        <MobileHeader eyebrow="Fulfilment" title="Deliveries" subtitle="Pack, dispatch, and complete deliveries." />
        {!!error && <Text style={styles.error}>{error}</Text>}
        {loading ? <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View> :
          rows.length ? <View style={styles.list}>{rows.map((row) => <RecordCard key={row.id} icon="car-outline" title={row.delivery_no || `Delivery #${row.id}`} subtitle={row.business_name || row.retailer_name || row.order_no} meta={`Created ${date(row.created_at)}`} status={row.status}><View style={styles.actions}>{["packed", "dispatched", "delivered"].map((status) => <Pressable key={status} disabled={workingId === row.id} style={[styles.action, row.status === status && styles.actionActive]} onPress={() => update(row, status)}><Text style={[styles.actionText, row.status === status && styles.actionTextActive]}>{status}</Text></Pressable>)}</View></RecordCard>)}</View> :
          <EmptyState icon="car-outline" title="No deliveries" copy="Delivery records will appear here." />}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  list: { gap: 0 },
  loading: { minHeight: 300, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 12, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
  actions: { marginTop: 12, flexDirection: "row", gap: 6 },
  action: { flex: 1, minHeight: 36, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border, borderRadius: 10 },
  actionActive: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  actionText: { color: colors.body, fontSize: 8, fontWeight: "800", textTransform: "capitalize" },
  actionTextActive: { color: colors.primary },
});
