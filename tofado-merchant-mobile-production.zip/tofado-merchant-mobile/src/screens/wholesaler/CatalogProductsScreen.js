import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import RecordCard from "../../components/RecordCard";
import EmptyState from "../../components/EmptyState";
import { money, date } from "../../utils/format";

export default function CatalogProductsScreen({ navigation }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async (refresh = false) => {
    try {
      refresh ? setRefreshing(true) : setLoading(true);
      setError("");
      const { data } = await api.get("/wholesaler/catalog/products");
      setRows(Array.isArray(data) ? data : data?.rows || data?.orders || data?.invoices || data?.payments || data?.deliveries || data?.products || data?.retailers || []);
    } catch (e) {
      setError(e?.response?.data?.message || "Unable to load data.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView
        contentContainerStyle={styles.page}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} tintColor={colors.primary} />}
      >
        <MobileHeader eyebrow="Catalog" title="Product catalog" subtitle="Your wholesale products and availability." />
        {!!error && <Text style={styles.error}>{error}</Text>}

        {loading ? (
          <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View>
        ) : rows.length ? (
          <View style={styles.list}>
            {rows.map((row) => (
              <RecordCard
                key={row.id}
                icon="cube-outline"
                title={row.name || `Product #${row.id}`}
                subtitle={row.brand || row.category_name || row.sku || ""}
                meta={row.unit || ""}
                amount={row.price != null ? money(row.price) : undefined}
                status={row.is_active != null ? (row.is_active ? "active" : "cancelled") : undefined}
              />
            ))}
          </View>
        ) : (
          <EmptyState icon="cube-outline" title="Nothing here yet" copy="Records will appear here when available." />
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  list: { gap: 0 },
  loading: { minHeight: 300, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 12, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
});
