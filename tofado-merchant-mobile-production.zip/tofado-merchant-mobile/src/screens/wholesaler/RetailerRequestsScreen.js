import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import api from "../../services/api";
import { colors } from "../../theme/colors";
import MobileHeader from "../../components/MobileHeader";
import RecordCard from "../../components/RecordCard";
import EmptyState from "../../components/EmptyState";

export default function RetailerRequestsScreen({ navigation }) {
  const [rows, setRows] = useState([]); const [loading, setLoading] = useState(true);
  const [workingId, setWorkingId] = useState(null); const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      setLoading(true); setError("");
      const { data } = await api.get("/wholesaler/retailer-requests");
      setRows(Array.isArray(data) ? data : data?.requests || []);
    } catch (e) { setError(e?.response?.data?.message || "Unable to load retailer requests."); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const respond = async (row, action) => {
    try {
      setWorkingId(row.connection_id); setError("");
      await api.patch(`/wholesaler/retailer-requests/${row.connection_id}`, { action });
      setRows((current) => current.filter((x) => x.connection_id !== row.connection_id));
    } catch (e) { setError(e?.response?.data?.message || "Unable to update request."); }
    finally { setWorkingId(null); }
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page}>
        <MobileHeader eyebrow="Connection requests" title="Retailer requests" subtitle="Approve retailers before they can order." onBack={() => navigation.goBack()} />
        {!!error && <Text style={styles.error}>{error}</Text>}
        {loading ? <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View> :
          rows.length ? <View style={styles.list}>{rows.map((row) => <RecordCard key={row.connection_id} icon="storefront-outline" title={row.business_name || "Retailer"} subtitle={row.location || row.name} meta={row.request_message || "Wants to connect"} status="pending"><View style={styles.actions}><Pressable disabled={workingId === row.connection_id} style={styles.reject} onPress={() => respond(row, "reject")}><Text style={styles.rejectText}>Reject</Text></Pressable><Pressable disabled={workingId === row.connection_id} style={styles.accept} onPress={() => respond(row, "accept")}><Text style={styles.acceptText}>{workingId === row.connection_id ? "Updating…" : "Accept"}</Text></Pressable></View></RecordCard>)}</View> :
          <EmptyState icon="checkmark-circle-outline" title="No pending requests" copy="New retailer requests will appear here." />}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  page: { padding: 20, paddingBottom: 34 },
  list: { gap: 0 },
  loading: { minHeight: 300, alignItems: "center", justifyContent: "center" },
  error: { marginBottom: 12, padding: 11, borderRadius: 11, color: colors.red, backgroundColor: colors.redSoft, fontSize: 10 },
  actions: { marginTop: 13, flexDirection: "row", gap: 8 },
  reject: { flex: 1, minHeight: 40, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#FECACA", borderRadius: 11, backgroundColor: colors.redSoft },
  rejectText: { color: colors.red, fontSize: 9, fontWeight: "900" },
  accept: { flex: 1, minHeight: 40, alignItems: "center", justifyContent: "center", borderRadius: 11, backgroundColor: colors.primary },
  acceptText: { color: colors.white, fontSize: 9, fontWeight: "900" },
});
