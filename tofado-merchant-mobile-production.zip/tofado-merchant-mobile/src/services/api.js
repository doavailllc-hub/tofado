import axios from "axios";

import { getToken } from "./tokenStore";

const api = axios.create({
  baseURL:
    process.env.EXPO_PUBLIC_API_URL ||
    "http://10.0.2.2:5000/api",
  timeout: 15000,
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
});

const inflightGets = new Map();

api.interceptors.request.use(async (config) => {
  const token = await getToken();

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.data && typeof error.response.data === "string") {
      error.response.data = { message: "The server returned an unexpected response." };
    }
    return Promise.reject(error);
  }
);

export async function getOnce(url, config = {}) {
  const key = `${url}:${JSON.stringify(config.params || {})}`;
  if (inflightGets.has(key)) return inflightGets.get(key);
  const request = api.get(url, config).finally(() => inflightGets.delete(key));
  inflightGets.set(key, request);
  return request;
}

export default api;
