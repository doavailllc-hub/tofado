import { Platform } from "react-native";
import * as SecureStore from "expo-secure-store";

const TOKEN_KEY = "tofado_token";
const USER_KEY = "tofado_user";

function webGet(key) {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(key);
}

function webSet(key, value) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, value);
}

function webRemove(key) {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(key);
}

export async function saveSession(token, user) {
  if (Platform.OS === "web") {
    webSet(TOKEN_KEY, token);
    webSet(USER_KEY, JSON.stringify(user));
    return;
  }

  await SecureStore.setItemAsync(TOKEN_KEY, token);
  await SecureStore.setItemAsync(USER_KEY, JSON.stringify(user));
}

export async function getToken() {
  if (Platform.OS === "web") {
    return webGet(TOKEN_KEY);
  }

  return SecureStore.getItemAsync(TOKEN_KEY);
}

export async function getStoredUser() {
  let value;

  if (Platform.OS === "web") {
    value = webGet(USER_KEY);
  } else {
    value = await SecureStore.getItemAsync(USER_KEY);
  }

  if (!value) return null;

  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

export async function updateStoredUser(user) {
  const value = JSON.stringify(user);

  if (Platform.OS === "web") {
    webSet(USER_KEY, value);
    return;
  }

  await SecureStore.setItemAsync(USER_KEY, value);
}

export async function clearSession() {
  if (Platform.OS === "web") {
    webRemove(TOKEN_KEY);
    webRemove(USER_KEY);
    return;
  }

  await SecureStore.deleteItemAsync(TOKEN_KEY);
  await SecureStore.deleteItemAsync(USER_KEY);
}
