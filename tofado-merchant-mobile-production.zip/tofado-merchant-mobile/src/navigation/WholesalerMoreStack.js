import { createNativeStackNavigator } from "@react-navigation/native-stack";
import WholesalerMoreScreen from "../screens/wholesaler/WholesalerMoreScreen";
import CatalogProductsScreen from "../screens/wholesaler/CatalogProductsScreen";
import WholesalerInvoicesScreen from "../screens/wholesaler/WholesalerInvoicesScreen";
import WholesalerPaymentsScreen from "../screens/wholesaler/WholesalerPaymentsScreen";
import ProfileScreen from "../screens/common/ProfileScreen";
const Stack = createNativeStackNavigator();
export default function WholesalerMoreStack() {
  return <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="MoreHome" component={WholesalerMoreScreen} />
    <Stack.Screen name="CatalogProducts" component={CatalogProductsScreen} />
    <Stack.Screen name="WholesalerInvoices" component={WholesalerInvoicesScreen} />
    <Stack.Screen name="WholesalerPayments" component={WholesalerPaymentsScreen} />
    <Stack.Screen name="Profile" component={ProfileScreen} />
  </Stack.Navigator>;
}
