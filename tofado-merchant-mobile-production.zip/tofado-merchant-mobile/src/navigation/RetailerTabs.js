import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import RetailerHomeScreen from "../screens/retailer/RetailerHomeScreen";
import RetailerVendorStack from "./RetailerVendorStack";
import RetailerOrdersStack from "./RetailerOrdersStack";
import RetailerInvoicesStack from "./RetailerInvoicesStack";
import ProfileScreen from "../screens/common/ProfileScreen";
import TabBarIcon from "./TabBarIcon";
import { colors } from "../theme/colors";

const Tab = createBottomTabNavigator();

export default function RetailerTabs() {
  return (
    <Tab.Navigator screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarHideOnKeyboard: true,
        tabBarLabelStyle: { fontSize: 9, fontWeight: "700", marginBottom: 7 },
        tabBarIconStyle: { marginTop: 6 },
        tabBarStyle: {
          height: 72,
          paddingTop: 2,
          borderTopWidth: 1,
          borderTopColor: colors.border,
          backgroundColor: colors.white,
          elevation: 12,
          shadowColor: "#000",
          shadowOpacity: 0.05,
          shadowRadius: 12,
          shadowOffset: { width: 0, height: -4 },
        },
      }}>
      <Tab.Screen name="RetailerHome" component={RetailerHomeScreen} options={{ title: "Home", tabBarIcon: ({ color, size }) => <TabBarIcon name="home-outline" color={color} size={size} /> }} />
      <Tab.Screen name="RetailerVendors" component={RetailerVendorStack} options={{ title: "Vendors", tabBarIcon: ({ color, size }) => <TabBarIcon name="people-outline" color={color} size={size} /> }} />
      <Tab.Screen name="RetailerOrders" component={RetailerOrdersStack} options={{ title: "Orders", tabBarIcon: ({ color, size }) => <TabBarIcon name="bag-handle-outline" color={color} size={size} /> }} />
      <Tab.Screen name="RetailerInvoices" component={RetailerInvoicesStack} options={{ title: "Invoices", tabBarIcon: ({ color, size }) => <TabBarIcon name="receipt-outline" color={color} size={size} /> }} />
      <Tab.Screen name="RetailerProfile" component={ProfileScreen} options={{ title: "Profile", tabBarIcon: ({ color, size }) => <TabBarIcon name="person-outline" color={color} size={size} /> }} />
    </Tab.Navigator>
  );
}
