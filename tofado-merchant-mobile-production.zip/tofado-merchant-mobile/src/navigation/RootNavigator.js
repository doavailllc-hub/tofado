import { createNativeStackNavigator } from "@react-navigation/native-stack";

import { useAuth } from "../context/AuthContext";
import LoginScreen from "../screens/auth/LoginScreen";
import BootScreen from "../screens/common/BootScreen";
import AdminNoticeScreen from "../screens/common/AdminNoticeScreen";
import RetailerTabs from "./RetailerTabs";
import WholesalerTabs from "./WholesalerTabs";

const Stack = createNativeStackNavigator();

export default function RootNavigator() {
  const { user, booting } = useAuth();

  if (booting) {
    return <BootScreen />;
  }

  if (!user) {
    return (
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
      </Stack.Navigator>
    );
  }

  if (user.role === "retailer") {
    return <RetailerTabs />;
  }

  if (user.role === "wholesaler") {
    return <WholesalerTabs />;
  }

  return <AdminNoticeScreen />;
}
