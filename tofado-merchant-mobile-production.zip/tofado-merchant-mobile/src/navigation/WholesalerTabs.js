import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import WholesalerHomeScreen from "../screens/wholesaler/WholesalerHomeScreen";
import WholesalerOrdersStack from "./WholesalerOrdersStack";
import WholesalerRetailersStack from "./WholesalerRetailersStack";
import WholesalerDeliveriesScreen from "../screens/wholesaler/WholesalerDeliveriesScreen";
import WholesalerMoreStack from "./WholesalerMoreStack";
import TabBarIcon from "./TabBarIcon";
import { colors } from "../theme/colors";

const Tab = createBottomTabNavigator();

export default function WholesalerTabs() {
  return (
    <Tab.Navigator screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarHideOnKeyboard: true,
        tabBarLabelStyle: { fontSize: 9, fontWeight: "700", marginBottom: 7 },
        tabBarIconStyle: { marginTop: 6 },
        tabBarStyle: {
          height: 72,
          paddingTop: 2,
          borderTopWidth: 1,
          borderTopColor: colors.border,
          backgroundColor: colors.white,
          elevation: 12,
          shadowColor: "#000",
          shadowOpacity: 0.05,
          shadowRadius: 12,
          shadowOffset: { width: 0, height: -4 },
        },
      }}>
      <Tab.Screen name="WholesalerHome" component={WholesalerHomeScreen} options={{ title: "Home", tabBarIcon: ({ color, size }) => <TabBarIcon name="home-outline" color={color} size={size} /> }} />
      <Tab.Screen name="WholesalerOrders" component={WholesalerOrdersStack} options={{ title: "Orders", tabBarIcon: ({ color, size }) => <TabBarIcon name="bag-handle-outline" color={color} size={size} /> }} />
      <Tab.Screen name="WholesalerRetailers" component={WholesalerRetailersStack} options={{ title: "Retailers", tabBarIcon: ({ color, size }) => <TabBarIcon name="people-outline" color={color} size={size} /> }} />
      <Tab.Screen name="WholesalerDeliveries" component={WholesalerDeliveriesScreen} options={{ title: "Deliveries", tabBarIcon: ({ color, size }) => <TabBarIcon name="car-outline" color={color} size={size} /> }} />
      <Tab.Screen name="WholesalerMore" component={WholesalerMoreStack} options={{ title: "More", tabBarIcon: ({ color, size }) => <TabBarIcon name="menu-outline" color={color} size={size} /> }} />
    </Tab.Navigator>
  );
}
