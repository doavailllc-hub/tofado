import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import api from "../services/api";
import {
  clearSession,
  getStoredUser,
  getToken,
  saveSession,
  updateStoredUser,
} from "../services/tokenStore";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);
  const [signingIn, setSigningIn] = useState(false);

  const logout = useCallback(async () => {
    await clearSession();
    setUser(null);
  }, []);

  const restoreSession = useCallback(async () => {
    try {
      const [token, storedUser] = await Promise.all([
        getToken(),
        getStoredUser(),
      ]);

      if (!token || !storedUser) {
        setUser(null);
        return;
      }

      setUser(storedUser);

      try {
        const { data } = await api.get("/auth/me");
        setUser(data);
        await updateStoredUser(data);
      } catch {
        await logout();
      }
    } finally {
      setBooting(false);
    }
  }, [logout]);

  useEffect(() => {
    restoreSession();
  }, [restoreSession]);

  const login = useCallback(async (email, password, remember = true) => {
    try {
      setSigningIn(true);

      const { data } = await api.post("/auth/login", {
        email: String(email || "").trim().toLowerCase(),
        password,
      });

      await saveSession(data.token, data.user, remember);
      setUser(data.user);

      return data.user;
    } finally {
      setSigningIn(false);
    }
  }, []);

  const refreshUser = useCallback(async () => {
    const { data } = await api.get("/auth/me");
    setUser(data);
    await updateStoredUser(data);
    return data;
  }, []);

  const value = useMemo(
    () => ({
      user,
      booting,
      signingIn,
      login,
      logout,
      refreshUser,
    }),
    [user, booting, signingIn, login, logout, refreshUser]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
