export const colors = {
  primary: "#176B45",
  primaryDark: "#105437",
  primarySoft: "#EAF6F0",
  green: "#16A34A",
  greenSoft: "#ECFDF3",
  orange: "#D97706",
  orangeSoft: "#FFF7ED",
  purple: "#7C3AED",
  purpleSoft: "#F5F3FF",
  red: "#DC2626",
  redSoft: "#FEF2F2",
  ink: "#17211B",
  body: "#536158",
  muted: "#8B9890",
  border: "#E3EAE5",
  borderStrong: "#D0D5DD",
  soft: "#F6F8F6",
  surface: "#FFFFFF",
  white: "#FFFFFF",
  black: "#101828",
};

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, xxxl: 32 };
export const radius = { sm: 10, md: 14, lg: 18, xl: 24, pill: 999 };
export const shadow = { shadowColor: "#17211B", shadowOpacity: 0.07, shadowRadius: 18, shadowOffset: { width: 0, height: 6 }, elevation: 3 };
